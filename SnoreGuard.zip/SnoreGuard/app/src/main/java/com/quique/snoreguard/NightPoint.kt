package com.quique.snoreguard

data class NightPoint(
    val timestampMs: Long,
    val totalEvents: Int,
    val apneaCount: Int
)
