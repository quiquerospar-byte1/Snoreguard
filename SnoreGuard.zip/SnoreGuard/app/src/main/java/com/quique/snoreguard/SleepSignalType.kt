package com.quique.snoreguard

/**
 * Ninguno de estos tipos es un diagnóstico médico -- son patrones acústicos
 * heurísticos relativos a tus propios ronquidos de esa noche. Ver
 * SignalRules.kt para los umbrales y SleepSignalAnalyzer.kt para la lógica.
 */
enum class SleepSignalType {
    DEEP_SNORE,
    POSSIBLE_BREATHING_PAUSE,
    IRREGULAR_PATTERN
}
