package com.quique.snoreguard

import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Codifica PCM 16-bit mono a AAC-LC dentro de un contenedor .m4a mediante
 * MediaCodec + MediaMuxer -- la combinación con más garantías de
 * reproducirse en cualquier Android sin depender de extractores menos
 * probados. (La versión anterior usaba AMR-NB "en crudo", más pequeño pero
 * que no se reprodujo de forma fiable en pruebas reales.)
 */
object AacClipEncoder {

    private const val MIME_TYPE = MediaFormat.MIMETYPE_AUDIO_AAC
    private const val BIT_RATE = 24_000
    private const val TIMEOUT_US = 10_000L

    fun encode(pcmSamples: ShortArray, sampleRate: Int, outputFile: File) {
        val format = MediaFormat.createAudioFormat(MIME_TYPE, sampleRate, 1).apply {
            setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
            setInteger(MediaFormat.KEY_BIT_RATE, BIT_RATE)
        }

        val codec = MediaCodec.createEncoderByType(MIME_TYPE)
        val muxer = MediaMuxer(outputFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        var muxerTrackIndex = -1
        var muxerStarted = false

        try {
            codec.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            codec.start()

            val pcmBytes = ByteBuffer.allocate(pcmSamples.size * 2)
                .order(ByteOrder.LITTLE_ENDIAN)
                .apply { pcmSamples.forEach { putShort(it) } }
                .array()

            var inputOffset = 0
            var eosSent = false
            var outputDone = false
            val bufferInfo = MediaCodec.BufferInfo()

            while (!outputDone) {
                if (!eosSent) {
                    val inputIndex = codec.dequeueInputBuffer(TIMEOUT_US)
                    if (inputIndex >= 0) {
                        val inputBuffer = codec.getInputBuffer(inputIndex)
                        inputBuffer?.clear()
                        val remaining = pcmBytes.size - inputOffset
                        val capacity = inputBuffer?.remaining() ?: 0
                        val toCopy = minOf(remaining, capacity)

                        if (toCopy > 0) {
                            inputBuffer?.put(pcmBytes, inputOffset, toCopy)
                            inputOffset += toCopy
                            codec.queueInputBuffer(inputIndex, 0, toCopy, 0, 0)
                        } else {
                            codec.queueInputBuffer(
                                inputIndex, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM
                            )
                            eosSent = true
                        }
                    }
                }

                val outputIndex = codec.dequeueOutputBuffer(bufferInfo, TIMEOUT_US)
                when {
                    outputIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        muxerTrackIndex = muxer.addTrack(codec.outputFormat)
                        muxer.start()
                        muxerStarted = true
                    }
                    outputIndex >= 0 -> {
                        val outputBuffer = codec.getOutputBuffer(outputIndex)
                        if (outputBuffer != null && bufferInfo.size > 0 && muxerStarted) {
                            muxer.writeSampleData(muxerTrackIndex, outputBuffer, bufferInfo)
                        }
                        codec.releaseOutputBuffer(outputIndex, false)
                        if (bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) {
                            outputDone = true
                        }
                    }
                }
            }
        } finally {
            codec.stop()
            codec.release()
            if (muxerStarted) {
                muxer.stop()
            }
            muxer.release()
        }
    }
}
