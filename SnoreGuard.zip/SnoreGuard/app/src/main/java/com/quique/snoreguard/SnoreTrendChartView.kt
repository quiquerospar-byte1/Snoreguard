package com.quique.snoreguard

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.util.AttributeSet
import android.view.View
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Locale

/**
 * Gráfico de líneas minimalista dibujado con Canvas, sin librerías externas.
 * Muestra dos series -eventos totales y posibles pausas respiratorias- por
 * noche, a lo largo de la ventana de tiempo que le pase [submitPoints].
 */
class SnoreTrendChartView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private var points: List<NightPoint> = emptyList()
    private val density = context.resources.displayMetrics.density
    private val scaledDensity = context.resources.displayMetrics.scaledDensity

    private val linePaintTotal = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = ContextCompat.getColor(context, R.color.primary)
        style = Paint.Style.STROKE
        strokeWidth = 2.5f * density
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }

    private val linePaintApnea = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = ContextCompat.getColor(context, R.color.signal_possible_apnea)
        style = Paint.Style.STROKE
        strokeWidth = 2.5f * density
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }

    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = ContextCompat.getColor(context, R.color.outline)
        style = Paint.Style.STROKE
        strokeWidth = 1f * density
    }

    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = ContextCompat.getColor(context, R.color.text_secondary)
        textSize = 11f * scaledDensity
    }

    private val dateFormat = SimpleDateFormat("d MMM", Locale.getDefault())

    fun submitPoints(newPoints: List<NightPoint>) {
        points = newPoints
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (points.isEmpty()) return

        val paddingLeft = 4f * density
        val paddingRight = 4f * density
        val paddingTop = 8f * density
        val paddingBottom = 24f * density

        val chartWidth = width - paddingLeft - paddingRight
        val chartHeight = height - paddingTop - paddingBottom
        if (chartWidth <= 0 || chartHeight <= 0) return

        val maxValue = points.maxOf { maxOf(it.totalEvents, it.apneaCount) }.coerceAtLeast(1)
        val stepX = if (points.size > 1) chartWidth / (points.size - 1) else 0f

        listOf(0f, 0.5f, 1f).forEach { fraction ->
            val y = paddingTop + chartHeight * (1 - fraction)
            canvas.drawLine(paddingLeft, y, paddingLeft + chartWidth, y, gridPaint)
        }

        fun yFor(value: Int): Float = paddingTop + chartHeight * (1 - value.toFloat() / maxValue.toFloat())

        val totalPath = Path()
        val apneaPath = Path()
        points.forEachIndexed { index, point ->
            val x = paddingLeft + stepX * index
            val yTotal = yFor(point.totalEvents)
            val yApnea = yFor(point.apneaCount)
            if (index == 0) {
                totalPath.moveTo(x, yTotal)
                apneaPath.moveTo(x, yApnea)
            } else {
                totalPath.lineTo(x, yTotal)
                apneaPath.lineTo(x, yApnea)
            }
        }
        canvas.drawPath(totalPath, linePaintTotal)
        canvas.drawPath(apneaPath, linePaintApnea)

        val labelIndices = if (points.size >= 3) {
            listOf(0, points.size / 2, points.size - 1)
        } else {
            points.indices.toList()
        }
        labelIndices.forEach { index ->
            val point = points[index]
            val x = paddingLeft + stepX * index
            val label = dateFormat.format(point.timestampMs)
            val textWidth = labelPaint.measureText(label)
            val labelX = when (index) {
                0 -> x
                points.size - 1 -> x - textWidth
                else -> x - textWidth / 2
            }
            canvas.drawText(label, labelX, height.toFloat() - 4f * density, labelPaint)
        }
    }
}
