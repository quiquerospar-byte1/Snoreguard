package com.quique.snoreguard

/**
 * Mantiene siempre en memoria los últimos [capacitySamples] samples de audio.
 * Se usa para poder guardar un clip de contexto cuando se confirma un ronquido,
 * sin necesidad de una segunda grabación simultánea (AudioRecord solo permite
 * un consumidor activo del micrófono a la vez de forma fiable).
 */
class AudioClipRingBuffer(private val capacitySamples: Int) {

    private val buffer = ShortArray(capacitySamples)
    private var writeIndex = 0
    private var filled = false

    @Synchronized
    fun write(frame: ShortArray) {
        for (sample in frame) {
            buffer[writeIndex] = sample
            writeIndex = (writeIndex + 1) % capacitySamples
            if (writeIndex == 0) filled = true
        }
    }

    @Synchronized
    fun snapshot(): ShortArray {
        if (!filled) {
            return buffer.copyOfRange(0, writeIndex)
        }
        val result = ShortArray(capacitySamples)
        System.arraycopy(buffer, writeIndex, result, 0, capacitySamples - writeIndex)
        System.arraycopy(buffer, 0, result, capacitySamples - writeIndex, writeIndex)
        return result
    }
}
