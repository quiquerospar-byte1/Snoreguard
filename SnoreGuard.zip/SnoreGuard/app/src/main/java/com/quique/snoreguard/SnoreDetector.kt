package com.quique.snoreguard

import kotlin.math.sqrt

/**
 * Detector heurístico, NO basado en machine learning.
 *
 * Clasifica cada frame de audio como "posible ronquido" si es lo bastante alto
 * (por encima del suelo de ruido adaptativo de la habitación) y su contenido es
 * predominantemente de baja frecuencia (aproximado con la tasa de cruces por cero,
 * ZCR). Agrupa frames consecutivos en "bursts" (un ronquido individual) y solo
 * confirma un "patrón de ronquido" cuando varios bursts se repiten con un ritmo
 * compatible con la respiración (cada 1.5-12s), para filtrar sonidos puntuales
 * como una tos, un golpe o hablar en sueños.
 *
 * Los umbrales (LOW_FREQ_ZCR_CEILING, MIN_ABSOLUTE_RMS, ventanas de ritmo en
 * Constants) son puntos de partida razonables, no valores calibrados con datos
 * reales. Es muy probable que necesites ajustarlos tras las primeras noches de uso
 * -- ver README.md.
 */
class SnoreDetector(
    private val sensitivity: Sensitivity,
    private val listener: Listener
) {

    interface Listener {
        fun onSnorePatternConfirmed(peakAmplitude: Int, burstDurationMs: Long)

        /**
         * Se llama para CADA burst individual registrado, confirme o no un
         * patrón rítmico. Es el punto de enganche para clasificación de
         * señales (ver SleepSignalAnalyzer.kt) sin tocar esta clase.
         */
        fun onBurstRegistered(startMs: Long, durationMs: Long, peakAmplitude: Int)
    }

    enum class Sensitivity(val thresholdMultiplier: Double) {
        LOW(3.5),
        MEDIUM(2.5),
        HIGH(1.8)
    }

    private var noiseFloor = 0.0
    private var noiseFloorInitialized = false
    private val calibrationSamples = mutableListOf<Double>()
    private val calibrationFrameCount = 100 // ~6.4s a 64ms/frame

    private var inBurst = false
    private var burstStartMs = 0L
    private var silenceRunLength = 0
    private var burstPeakAmplitude = 0

    private val recentBurstTimestamps = ArrayDeque<Long>()

    fun processFrame(frame: ShortArray, frameTimestampMs: Long) {
        val rms = computeRms(frame)
        val zcr = computeZeroCrossingRate(frame)

        if (!noiseFloorInitialized) {
            calibrationSamples.add(rms)
            if (calibrationSamples.size >= calibrationFrameCount) {
                calibrationSamples.sort()
                noiseFloor = calibrationSamples[calibrationSamples.size / 2]
                noiseFloorInitialized = true
            }
            return
        }

        val threshold = noiseFloor * sensitivity.thresholdMultiplier
        val isLowFrequencyDominant = zcr < LOW_FREQ_ZCR_CEILING
        val isLoudEnough = rms > threshold && rms > MIN_ABSOLUTE_RMS
        val isSnoreLikeFrame = isLoudEnough && isLowFrequencyDominant

        when {
            isSnoreLikeFrame -> {
                if (!inBurst) {
                    inBurst = true
                    burstStartMs = frameTimestampMs
                    burstPeakAmplitude = 0
                }
                silenceRunLength = 0
                burstPeakAmplitude = maxOf(burstPeakAmplitude, rms.toInt())
            }

            inBurst -> {
                silenceRunLength++
                if (silenceRunLength > Constants.MAX_SILENCE_GAP_FRAMES) {
                    val burstDurationMs = frameTimestampMs - burstStartMs
                    val burstFrames = burstDurationMs / Constants.FRAME_DURATION_MS
                    inBurst = false
                    silenceRunLength = 0
                    if (burstFrames >= Constants.MIN_BURST_FRAMES) {
                        registerBurst(burstStartMs, burstDurationMs, burstPeakAmplitude)
                    }
                }
            }

            else -> {
                // Fuera de un burst: deja que el suelo de ruido siga a la habitación
                // lentamente, para adaptarse a distintos dormitorios sin recalibrar.
                if (rms < noiseFloor * 1.2) {
                    noiseFloor = noiseFloor * 0.98 + rms * 0.02
                }
            }
        }
    }

    private fun registerBurst(startMs: Long, durationMs: Long, peakAmplitude: Int) {
        listener.onBurstRegistered(startMs, durationMs, peakAmplitude)

        recentBurstTimestamps.addLast(startMs)
        val cutoff = startMs - Constants.BURST_HISTORY_WINDOW_MS
        while (recentBurstTimestamps.isNotEmpty() && recentBurstTimestamps.first() < cutoff) {
            recentBurstTimestamps.removeFirst()
        }

        if (recentBurstTimestamps.size >= Constants.MIN_BURSTS_FOR_PATTERN &&
            hasConsistentRhythm(recentBurstTimestamps.toList())
        ) {
            listener.onSnorePatternConfirmed(peakAmplitude, durationMs)
        }
    }

    private fun hasConsistentRhythm(timestamps: List<Long>): Boolean {
        val recent = timestamps.takeLast(Constants.MIN_BURSTS_FOR_PATTERN)
        for (i in 1 until recent.size) {
            val gap = recent[i] - recent[i - 1]
            if (gap < Constants.MIN_INTERVAL_BETWEEN_BURSTS_MS ||
                gap > Constants.MAX_INTERVAL_BETWEEN_BURSTS_MS
            ) {
                return false
            }
        }
        return true
    }

    private fun computeRms(frame: ShortArray): Double {
        var sum = 0.0
        for (sample in frame) {
            val value = sample.toDouble()
            sum += value * value
        }
        return sqrt(sum / frame.size)
    }

    private fun computeZeroCrossingRate(frame: ShortArray): Double {
        var crossings = 0
        for (i in 1 until frame.size) {
            if ((frame[i - 1] >= 0) != (frame[i] >= 0)) crossings++
        }
        return crossings.toDouble() / frame.size
    }

    companion object {
        // La ZCR es proporcional a frecuencia/sampleRate: al bajar Constants.SAMPLE_RATE
        // de 16kHz a 8kHz, este valor se duplicó (de 0.12 a 0.24) para conservar el
        // mismo corte real de ~960Hz. Si vuelves a tocar SAMPLE_RATE, reescala este
        // valor en la misma proporción o el detector se volverá más estricto sin avisar.
        private const val LOW_FREQ_ZCR_CEILING = 0.24
        private const val MIN_ABSOLUTE_RMS = 150.0
    }
}
