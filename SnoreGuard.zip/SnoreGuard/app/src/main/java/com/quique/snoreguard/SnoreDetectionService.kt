package com.quique.snoreguard

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioRecord
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.media.RingtoneManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.os.Process
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean

class SnoreDetectionService : Service(), SnoreDetector.Listener {

    private var audioRecord: AudioRecord? = null
    private var recordingThread: Thread? = null
    private val isRunning = AtomicBoolean(false)

    private var wakeLock: PowerManager.WakeLock? = null
    private lateinit var detector: SnoreDetector
    private lateinit var signalAnalyzer: SleepSignalAnalyzer
    private lateinit var ringBuffer: AudioClipRingBuffer
    private var vibrateEnabled = true
    private var soundEnabled = true

    private var lastAlertTimestampMs = 0L
    private var lastLoggedTimestampMs = 0L
    private val lastSignalLoggedTimestamps = mutableMapOf<SleepSignalType, Long>()
    private var eventCount = 0

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private lateinit var dao: SnoreEventDao

    private var vibrator: Vibrator? = null
    private var alertPlayer: MediaPlayer? = null

    override fun onCreate() {
        super.onCreate()
        dao = SnoreDatabase.getInstance(applicationContext).snoreEventDao()
        vibrator = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        createNotificationChannel()
        serviceScope.launch {
            val cutoff = System.currentTimeMillis() -
                Constants.EVENT_RETENTION_DAYS * 24 * 60 * 60 * 1000
            dao.deleteOlderThan(cutoff)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == Constants.ACTION_STOP) {
            stopDetection()
            stopSelf()
            return START_NOT_STICKY
        }

        val sensitivityName = intent?.getStringExtra(Constants.EXTRA_SENSITIVITY)
            ?: SnoreDetector.Sensitivity.MEDIUM.name
        val sensitivity = SnoreDetector.Sensitivity.valueOf(sensitivityName)

        vibrateEnabled = intent?.getBooleanExtra(Constants.EXTRA_VIBRATE_ENABLED, true) ?: true
        soundEnabled = intent?.getBooleanExtra(Constants.EXTRA_SOUND_ENABLED, true) ?: true

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                Constants.NOTIFICATION_ID,
                buildNotification(),
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            )
        } else {
            startForeground(Constants.NOTIFICATION_ID, buildNotification())
        }

        startDetection(sensitivity)
        return START_STICKY
    }

    private fun startDetection(sensitivity: SnoreDetector.Sensitivity) {
        if (isRunning.get()) return

        val minBufferSize = AudioRecord.getMinBufferSize(
            Constants.SAMPLE_RATE, Constants.CHANNEL_CONFIG, Constants.AUDIO_FORMAT
        )
        if (minBufferSize == AudioRecord.ERROR_BAD_VALUE || minBufferSize == AudioRecord.ERROR) {
            stopSelf()
            return
        }
        val bufferSize = maxOf(minBufferSize, Constants.FRAME_SIZE_SAMPLES * 2 * 4)

        val record = try {
            AudioRecord(
                MediaRecorder.AudioSource.MIC,
                Constants.SAMPLE_RATE,
                Constants.CHANNEL_CONFIG,
                Constants.AUDIO_FORMAT,
                bufferSize
            )
        } catch (e: SecurityException) {
            stopSelf()
            return
        }

        if (record.state != AudioRecord.STATE_INITIALIZED) {
            record.release()
            stopSelf()
            return
        }

        audioRecord = record
        detector = SnoreDetector(sensitivity, this)
        signalAnalyzer = SleepSignalAnalyzer()
        ringBuffer = AudioClipRingBuffer(Constants.RING_BUFFER_SAMPLES)

        val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = powerManager.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK, "SnoreGuard::RecordingWakeLock"
        ).apply { acquire(12 * 60 * 60 * 1000L) }

        isRunning.set(true)
        record.startRecording()

        recordingThread = Thread {
            // Prioridad específica de audio en tiempo real de Android: el sistema
            // la programa de forma más eficiente (menos contención, menos consumo)
            // que un Thread.MAX_PRIORITY genérico de Java.
            Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)
            val frame = ShortArray(Constants.FRAME_SIZE_SAMPLES)
            while (isRunning.get()) {
                val read = record.read(frame, 0, frame.size)
                if (read > 0) {
                    val timestamp = System.currentTimeMillis()
                    val chunk = if (read == frame.size) frame else frame.copyOf(read)
                    ringBuffer.write(chunk)
                    detector.processFrame(chunk, timestamp)
                }
            }
        }.apply {
            name = "SnoreGuard-RecordingThread"
            start()
        }
    }

    override fun onSnorePatternConfirmed(peakAmplitude: Int, burstDurationMs: Long) {
        // Esta función la llama directamente el hilo de audio en tiempo real
        // (ver processFrame en el bucle de startDetection). Por eso la decisión
        // de cooldown se resuelve aquí mismo con dos comparaciones de Long -sin
        // I/O- y solo se despacha una corrutina cuando hay trabajo real que hacer.
        // Al ser siempre el mismo hilo quien lee y actualiza lastAlertTimestampMs/
        // lastLoggedTimestampMs, no hace falta sincronización adicional.
        val now = System.currentTimeMillis()

        val shouldAlert = (vibrateEnabled || soundEnabled) &&
            (now - lastAlertTimestampMs) > Constants.ALERT_COOLDOWN_MS
        if (shouldAlert) lastAlertTimestampMs = now

        val shouldLog = (now - lastLoggedTimestampMs) > Constants.EVENT_LOG_COOLDOWN_MS
        if (shouldLog) lastLoggedTimestampMs = now

        if (!shouldAlert && !shouldLog) return

        // El snapshot del anillo de audio sí debe capturarse aquí, de forma
        // síncrona: es el propio hilo de audio quien sigue escribiendo en él,
        // así que diferirlo a la corrutina capturaría una ventana de tiempo
        // distinta (más tardía) a la del evento real.
        val clipSnapshot = if (shouldLog) ringBuffer.snapshot() else null

        serviceScope.launch {
            if (shouldAlert) triggerAlert()

            if (shouldLog) {
                val clipFile = clipSnapshot?.let { saveClip(it, now) }
                dao.insert(
                    SnoreEvent(
                        timestampMs = now,
                        estimatedDurationMs = burstDurationMs,
                        peakAmplitude = peakAmplitude,
                        clipFilePath = clipFile?.absolutePath
                    )
                )
                enforceClipLimit()
                eventCount++
                updateNotification()
            }
        }
    }

    override fun onBurstRegistered(startMs: Long, durationMs: Long, peakAmplitude: Int) {
        // El análisis en sí es aritmética sobre ~20 números en memoria -no hay
        // I/O-, así que puede correr en cada burst sin coste real de batería.
        // Solo lo caro (escribir a disco/BD) se limita por cooldown, y por
        // tipo de señal para que un ronquido profundo continuo no le quite el
        // hueco a una posible pausa respiratoria que llegue poco después.
        val signal = signalAnalyzer.analyze(startMs, durationMs, peakAmplitude) ?: return

        val lastLoggedForType = lastSignalLoggedTimestamps[signal] ?: 0L
        if ((startMs - lastLoggedForType) <= SignalRules.SIGNAL_LOG_COOLDOWN_MS) return
        lastSignalLoggedTimestamps[signal] = startMs

        val clipSnapshot = ringBuffer.snapshot()
        serviceScope.launch {
            val clipFile = saveClip(clipSnapshot, startMs)
            dao.insert(
                SnoreEvent(
                    timestampMs = startMs,
                    estimatedDurationMs = durationMs,
                    peakAmplitude = peakAmplitude,
                    clipFilePath = clipFile?.absolutePath,
                    signalType = signal.name
                )
            )
            enforceClipLimit()
            eventCount++
            updateNotification()
        }
    }

    private fun saveClip(samples: ShortArray, timestampMs: Long): File? {
        return try {
            val clipsDir = File(filesDir, "clips").apply { mkdirs() }
            val outFile = File(clipsDir, "snore_$timestampMs.amr")
            AmrNbClipEncoder.encode(samples, Constants.SAMPLE_RATE, outFile)
            outFile
        } catch (e: Exception) {
            null
        }
    }

    private suspend fun enforceClipLimit() {
        val paths = dao.getAllClipPathsOldestFirst()
        val excess = paths.size - Constants.MAX_STORED_CLIPS
        if (excess > 0) {
            paths.take(excess).forEach { File(it).delete() }
        }
    }

    private fun triggerAlert() {
        if (vibrateEnabled) {
            vibrator?.let { v ->
                val pattern = longArrayOf(0, 400, 200, 400)
                v.vibrate(VibrationEffect.createWaveform(pattern, -1))
            }
        }

        if (soundEnabled) {
            try {
                alertPlayer?.release()
                val uri = RingtoneManager.getActualDefaultRingtoneUri(
                    this, RingtoneManager.TYPE_NOTIFICATION
                ) ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
                alertPlayer = MediaPlayer.create(this, uri)?.apply {
                    setVolume(0.3f, 0.3f)
                    setOnCompletionListener { it.release(); alertPlayer = null }
                    start()
                }
            } catch (e: Exception) {
                // El sonido es un extra; si falla, la vibración (si está activa) sigue avisando.
            }
        }
    }

    private fun stopDetection() {
        isRunning.set(false)
        recordingThread?.join(500)
        recordingThread = null

        audioRecord?.apply {
            try { stop() } catch (e: IllegalStateException) { /* ya estaba parado */ }
            release()
        }
        audioRecord = null

        wakeLock?.let { if (it.isHeld) it.release() }
        wakeLock = null

        alertPlayer?.release()
        alertPlayer = null
    }

    override fun onDestroy() {
        stopDetection()
        serviceScope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            Constants.NOTIFICATION_CHANNEL_ID,
            getString(R.string.notification_channel_name),
            NotificationManager.IMPORTANCE_LOW
        )
        (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
            .createNotificationChannel(channel)
    }

    private fun buildNotification(): Notification {
        val stopIntent = Intent(this, SnoreDetectionService::class.java).apply {
            action = Constants.ACTION_STOP
        }
        val stopPendingIntent = PendingIntent.getService(
            this, 0, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val openPendingIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, Constants.NOTIFICATION_CHANNEL_ID)
            .setContentTitle(getString(R.string.notification_title))
            .setContentText(getString(R.string.notification_text_format, eventCount))
            .setSmallIcon(R.drawable.ic_notification)
            .setContentIntent(openPendingIntent)
            .addAction(0, getString(R.string.stop), stopPendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun updateNotification() {
        (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
            .notify(Constants.NOTIFICATION_ID, buildNotification())
    }
}
