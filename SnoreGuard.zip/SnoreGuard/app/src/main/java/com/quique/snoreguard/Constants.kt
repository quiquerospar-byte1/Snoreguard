package com.quique.snoreguard

import android.media.AudioFormat

object Constants {

    // 8kHz es suficiente: el contenido espectral del ronquido está muy por debajo
    // de los 4kHz de Nyquist que da esta tasa, y reduce a la mitad CPU, RAM y
    // tamaño de los clips frente a los 16kHz anteriores.
    const val SAMPLE_RATE = 8000
    const val CHANNEL_CONFIG = AudioFormat.CHANNEL_IN_MONO
    const val AUDIO_FORMAT = AudioFormat.ENCODING_PCM_16BIT

    const val FRAME_DURATION_MS = 64L
    val FRAME_SIZE_SAMPLES = (SAMPLE_RATE * FRAME_DURATION_MS / 1000).toInt()

    const val RING_BUFFER_SECONDS = 5
    val RING_BUFFER_SAMPLES = SAMPLE_RATE * RING_BUFFER_SECONDS

    // Duración mínima de sonido continuo para contar como "ronquido individual".
    const val MIN_BURST_FRAMES = 4
    // Frames de silencio tolerados dentro de un mismo ronquido antes de darlo por terminado.
    const val MAX_SILENCE_GAP_FRAMES = 3
    // Un ronquido individual es breve. Un sonido sostenido más largo que esto
    // (motor de coche al ralentí, por ejemplo) no cuenta para el patrón
    // rítmico, aunque sí se sigue analizando como posible señal aparte
    // (ver SleepSignalAnalyzer -- "patrón irregular").
    const val MAX_BURST_DURATION_MS = 2_500L

    // Ventana en la que se buscan ronquidos repetidos con ritmo respiratorio.
    // Ceñida al ritmo real de respiración dormido (grosso modo 8-20
    // respiraciones/min) para no confundir con el ritmo de una alarma de
    // móvil o el traqueteo de un motor, que pueden ser igual de regulares
    // pero a un ritmo distinto.
    const val BURST_HISTORY_WINDOW_MS = 60_000L
    const val MIN_BURSTS_FOR_PATTERN = 4
    const val MIN_INTERVAL_BETWEEN_BURSTS_MS = 2_000L
    const val MAX_INTERVAL_BETWEEN_BURSTS_MS = 9_000L

    // Cooldown del AVISO (vibración/sonido): cada cuánto como mínimo se te nudgea.
    const val ALERT_COOLDOWN_MS = 90_000L

    // Cooldown del REGISTRO (guardar en BD + clip): antes no existía, y con
    // ronquido continuo se podía llegar a disparar un guardado cada 3-8s durante
    // toda la noche (miles de escrituras a disco). Con 10 min de cooldown, 50
    // clips cubren de forma representativa una noche completa (~8h) en vez de
    // agotarse en las 2 primeras horas.
    const val EVENT_LOG_COOLDOWN_MS = 600_000L
    const val MAX_STORED_CLIPS = 50
    const val EVENT_RETENTION_DAYS = 30L

    // Los resúmenes nocturnos no llevan audio, así que se pueden retener
    // mucho más tiempo que los eventos detallados sin coste real de espacio
    // -- lo bastante para alimentar el gráfico de 3 meses.
    const val SUMMARY_RETENTION_DAYS = 400L

    const val NOTIFICATION_CHANNEL_ID = "snore_guard_service"
    const val NOTIFICATION_ID = 1001

    const val ACTION_STOP = "com.quique.snoreguard.action.STOP"
    const val EXTRA_SENSITIVITY = "extra_sensitivity"
    const val EXTRA_VIBRATE_ENABLED = "extra_vibrate_enabled"
    const val EXTRA_SOUND_ENABLED = "extra_sound_enabled"
}
