package com.quique.snoreguard

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.quique.snoreguard.databinding.ActivityMainBinding
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var adapter: EventsAdapter
    private lateinit var dao: SnoreEventDao
    private var playingClip: MediaPlayer? = null
    private var serviceRunning = false

    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        val audioGranted = results[Manifest.permission.RECORD_AUDIO] ?: false
        if (audioGranted) {
            startDetectionService()
        } else {
            Toast.makeText(
                this, getString(R.string.permission_denied_message), Toast.LENGTH_LONG
            ).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        dao = SnoreDatabase.getInstance(applicationContext).snoreEventDao()

        setupEventsList()

        binding.startStopButton.setOnClickListener {
            if (serviceRunning) stopDetectionFlow() else requestPermissionsAndStart()
        }

        maybeRequestBatteryOptimizationExemption()
        observeEvents()
    }

    private fun setupEventsList() {
        adapter = EventsAdapter { event -> playClip(event) }
        binding.eventsRecyclerView.layoutManager = LinearLayoutManager(this)
        binding.eventsRecyclerView.adapter = adapter
    }

    private fun observeEvents() {
        lifecycleScope.launch {
            dao.observeAll().collect { events ->
                adapter.submitList(events)
                binding.summaryText.text = buildSummaryText(events)
                binding.emptyStateText.visibility =
                    if (events.isEmpty()) View.VISIBLE else View.GONE
            }
        }
    }

    private fun buildSummaryText(events: List<SnoreEvent>): String {
        val base = getString(R.string.summary_format, events.size)
        val deepSnores = events.count { it.signalType == SleepSignalType.DEEP_SNORE.name }
        val possiblePauses = events.count { it.signalType == SleepSignalType.POSSIBLE_BREATHING_PAUSE.name }
        if (deepSnores == 0 && possiblePauses == 0) return base
        return base + "\n" + getString(R.string.summary_signals_format, deepSnores, possiblePauses)
    }

    private fun requestPermissionsAndStart() {
        val permissions = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        val allGranted = permissions.all {
            ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
        }
        if (allGranted) startDetectionService() else requestPermissionLauncher.launch(permissions.toTypedArray())
    }

    private fun startDetectionService() {
        val sensitivity = when (binding.sensitivityToggleGroup.checkedButtonId) {
            R.id.sensitivityLowButton -> SnoreDetector.Sensitivity.LOW
            R.id.sensitivityHighButton -> SnoreDetector.Sensitivity.HIGH
            else -> SnoreDetector.Sensitivity.MEDIUM
        }
        val intent = Intent(this, SnoreDetectionService::class.java).apply {
            putExtra(Constants.EXTRA_SENSITIVITY, sensitivity.name)
            putExtra(Constants.EXTRA_VIBRATE_ENABLED, binding.vibrateCheckBox.isChecked)
            putExtra(Constants.EXTRA_SOUND_ENABLED, binding.soundCheckBox.isChecked)
        }
        ContextCompat.startForegroundService(this, intent)
        serviceRunning = true
        updateStartStopButton()
    }

    private fun stopDetectionFlow() {
        startService(Intent(this, SnoreDetectionService::class.java).apply {
            action = Constants.ACTION_STOP
        })
        serviceRunning = false
        updateStartStopButton()
    }

    private fun updateStartStopButton() {
        binding.startStopButton.text = getString(
            if (serviceRunning) R.string.stop_monitoring else R.string.start_monitoring
        )
        binding.vibrateCheckBox.isEnabled = !serviceRunning
        binding.soundCheckBox.isEnabled = !serviceRunning
        for (i in 0 until binding.sensitivityToggleGroup.childCount) {
            binding.sensitivityToggleGroup.getChildAt(i).isEnabled = !serviceRunning
        }
    }

    private fun maybeRequestBatteryOptimizationExemption() {
        val powerManager = getSystemService(POWER_SERVICE) as PowerManager
        if (!powerManager.isIgnoringBatteryOptimizations(packageName)) {
            try {
                startActivity(
                    Intent(
                        Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                        Uri.parse("package:$packageName")
                    )
                )
            } catch (e: Exception) {
                // Algunas capas de fabricante (Xiaomi, Huawei...) bloquean este intent;
                // el usuario puede activarlo a mano desde Ajustes > Batería.
            }
        }
    }

    private fun playClip(event: SnoreEvent) {
        val path = event.clipFilePath ?: return
        playingClip?.release()
        playingClip = MediaPlayer().apply {
            setDataSource(path)
            prepare()
            start()
        }
    }

    override fun onDestroy() {
        playingClip?.release()
        super.onDestroy()
    }
}
