package com.quique.snoreguard

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.GravityCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.quique.snoreguard.databinding.ActivityMainBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var adapter: EventsAdapter
    private lateinit var dao: SnoreEventDao
    private lateinit var summaryDao: NightlySummaryDao
    private var playingClip: MediaPlayer? = null
    private var serviceRunning = false

    private var latestSummaries: List<NightlySummary> = emptyList()
    private var trendDays = 7

    private val dayKeyFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())

    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        val audioGranted = results[Manifest.permission.RECORD_AUDIO] ?: false
        if (audioGranted) {
            startDetectionService()
        } else {
            Toast.makeText(
                this, getString(R.string.permission_denied_message), Toast.LENGTH_LONG
            ).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val database = SnoreDatabase.getInstance(applicationContext)
        dao = database.snoreEventDao()
        summaryDao = database.nightlySummaryDao()

        setupDrawer()
        setupEventsList()
        setupTrendChart()

        binding.startStopButton.setOnClickListener {
            if (serviceRunning) stopDetectionFlow() else requestPermissionsAndStart()
        }

        maybeRequestBatteryOptimizationExemption()
        observeEvents()
        observeTrend()
    }

    // ---------------------------------------------------------------
    // Navegación (menú hamburguesa)
    // ---------------------------------------------------------------

    private fun setupDrawer() {
        binding.menuButton.setOnClickListener {
            binding.drawerLayout.openDrawer(GravityCompat.START)
        }
        binding.navigationView.setNavigationItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> showSection(showHome = true)
                R.id.nav_history -> showSection(showHome = false)
            }
            binding.drawerLayout.closeDrawers()
            true
        }
    }

    private fun showSection(showHome: Boolean) {
        binding.homeContainer.visibility = if (showHome) View.VISIBLE else View.GONE
        binding.historyContainer.visibility = if (showHome) View.GONE else View.VISIBLE
    }

    // ---------------------------------------------------------------
    // Historial
    // ---------------------------------------------------------------

    private fun setupEventsList() {
        adapter = EventsAdapter(
            onPlayClicked = { event -> playClip(event) },
            onDeleteEventClicked = { event -> confirmDeleteEvent(event) },
            onDeleteDayClicked = { dayKey, dayLabel -> confirmDeleteDay(dayKey, dayLabel) }
        )
        binding.eventsRecyclerView.layoutManager = LinearLayoutManager(this)
        binding.eventsRecyclerView.adapter = adapter
    }

    private fun observeEvents() {
        lifecycleScope.launch {
            dao.observeAll().collect { events ->
                adapter.submitList(buildListItems(events))
                binding.summaryText.text = buildSummaryText(events)
                binding.emptyStateText.visibility =
                    if (events.isEmpty()) View.VISIBLE else View.GONE
            }
        }
    }

    private fun buildListItems(events: List<SnoreEvent>): List<EventListItem> {
        val countsByDay = events.groupingBy { dayKeyFormat.format(Date(it.timestampMs)) }.eachCount()
        val items = mutableListOf<EventListItem>()
        var currentDayKey: String? = null

        for (event in events) {
            val key = dayKeyFormat.format(Date(event.timestampMs))
            if (key != currentDayKey) {
                currentDayKey = key
                items.add(EventListItem.DayHeader(dayLabel(event.timestampMs), key, countsByDay[key] ?: 0))
            }
            items.add(EventListItem.EventRow(event))
        }
        return items
    }

    private fun dayLabel(timestampMs: Long): String {
        fun isSameDay(a: Calendar, b: Calendar) =
            a.get(Calendar.YEAR) == b.get(Calendar.YEAR) && a.get(Calendar.DAY_OF_YEAR) == b.get(Calendar.DAY_OF_YEAR)

        val eventCal = Calendar.getInstance().apply { timeInMillis = timestampMs }
        val today = Calendar.getInstance()
        val yesterday = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -1) }

        return when {
            isSameDay(eventCal, today) -> getString(R.string.day_today)
            isSameDay(eventCal, yesterday) -> getString(R.string.day_yesterday)
            else -> SimpleDateFormat("d MMM yyyy", Locale.getDefault()).format(Date(timestampMs))
        }
    }

    private fun buildSummaryText(events: List<SnoreEvent>): String {
        val base = getString(R.string.summary_format, events.size)
        val deepSnores = events.count { it.signalType == SleepSignalType.DEEP_SNORE.name }
        val possiblePauses = events.count { it.signalType == SleepSignalType.POSSIBLE_BREATHING_PAUSE.name }
        if (deepSnores == 0 && possiblePauses == 0) return base
        return base + "\n" + getString(R.string.summary_signals_format, deepSnores, possiblePauses)
    }

    private fun confirmDeleteDay(dayKey: String, dayLabel: String) {
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.delete_day_title, dayLabel))
            .setMessage(R.string.delete_day_message)
            .setNegativeButton(R.string.cancel, null)
            .setPositiveButton(R.string.delete) { _, _ -> deleteDay(dayKey) }
            .show()
    }

    private fun deleteDay(dayKey: String) {
        val startMs = dayKeyFormat.parse(dayKey)!!.time
        val endMs = Calendar.getInstance().apply {
            timeInMillis = startMs
            add(Calendar.DAY_OF_YEAR, 1)
        }.timeInMillis

        lifecycleScope.launch {
            withContext(Dispatchers.IO) {
                val clipPaths = dao.getClipPathsBetween(startMs, endMs)
                clipPaths.forEach { File(it).delete() }
                dao.deleteBetween(startMs, endMs)
            }
        }
    }

    private fun confirmDeleteEvent(event: SnoreEvent) {
        AlertDialog.Builder(this)
            .setTitle(R.string.delete_event_title)
            .setMessage(R.string.delete_event_message)
            .setNegativeButton(R.string.cancel, null)
            .setPositiveButton(R.string.delete) { _, _ -> deleteEvent(event) }
            .show()
    }

    private fun deleteEvent(event: SnoreEvent) {
        lifecycleScope.launch {
            withContext(Dispatchers.IO) {
                event.clipFilePath?.let { File(it).delete() }
                dao.deleteById(event.id)
            }
        }
    }

    // ---------------------------------------------------------------
    // Gráfico de tendencia
    // ---------------------------------------------------------------

    private fun setupTrendChart() {
        binding.trendRangeToggleGroup.addOnButtonCheckedListener { _, checkedId, isChecked ->
            if (!isChecked) return@addOnButtonCheckedListener
            trendDays = when (checkedId) {
                R.id.trendRange30Button -> 30
                R.id.trendRange90Button -> 90
                else -> 7
            }
            updateTrendChart()
        }
        binding.shareSummaryButton.setOnClickListener { shareSummary() }
    }

    private fun shareSummary() {
        val rangeStartMs = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -trendDays) }.timeInMillis
        lifecycleScope.launch {
            val apneaEvents = withContext(Dispatchers.IO) {
                dao.getEventsBySignalSince(SleepSignalType.POSSIBLE_BREATHING_PAUSE.name, rangeStartMs)
            }
            val shareText = buildShareText(apneaEvents)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, shareText)
            }
            startActivity(Intent.createChooser(intent, getString(R.string.share_summary)))
        }
    }

    private fun buildShareText(apneaEvents: List<SnoreEvent>): String {
        val points = buildChartSeries(latestSummaries, trendDays)
        val totalSnores = points.sumOf { it.totalEvents }
        val totalApneas = points.sumOf { it.apneaCount }
        val rangeLabel = when (trendDays) {
            30 -> getString(R.string.trend_30d)
            90 -> getString(R.string.trend_90d)
            else -> getString(R.string.trend_7d)
        }

        val eventTimeFormat = SimpleDateFormat("d MMM HH:mm", Locale.getDefault())
        val durationsText = if (apneaEvents.isEmpty()) {
            getString(R.string.share_no_apneas)
        } else {
            apneaEvents.joinToString("\n") { event ->
                "- ${eventTimeFormat.format(event.timestampMs)} — ${event.estimatedDurationMs / 1000} s"
            }
        }

        return getString(R.string.share_summary_format, rangeLabel, totalSnores, totalApneas, durationsText)
    }

    private fun observeTrend() {
        val startKey = dayKeyFormat.format(
            Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -90) }.time
        )
        lifecycleScope.launch {
            summaryDao.observeSince(startKey).collect { summaries ->
                latestSummaries = summaries
                updateTrendChart()
            }
        }
    }

    private fun updateTrendChart() {
        binding.trendChartView.submitPoints(buildChartSeries(latestSummaries, trendDays))

        val comparisonText = buildWeeklyComparisonText()
        binding.weeklyComparisonText.text = comparisonText
        binding.weeklyComparisonText.visibility = if (comparisonText != null) View.VISIBLE else View.GONE
    }

    private fun buildWeeklyComparisonText(): String? {
        val thisWeekStart = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -6) }
        val lastWeekStart = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -13) }
        val lastWeekEnd = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -7) }
        val today = Calendar.getInstance()

        fun sumBetween(start: Calendar, end: Calendar): Int {
            val startKey = dayKeyFormat.format(start.time)
            val endKey = dayKeyFormat.format(end.time)
            return latestSummaries.filter { it.dayKey in startKey..endKey }.sumOf { it.totalEvents }
        }

        val thisWeekTotal = sumBetween(thisWeekStart, today)
        val lastWeekTotal = sumBetween(lastWeekStart, lastWeekEnd)
        if (lastWeekTotal == 0) return null

        val percentChange = ((thisWeekTotal - lastWeekTotal).toDouble() / lastWeekTotal * 100).toInt()
        return when {
            percentChange < 0 -> getString(R.string.weekly_comparison_less, thisWeekTotal, -percentChange)
            percentChange > 0 -> getString(R.string.weekly_comparison_more, thisWeekTotal, percentChange)
            else -> getString(R.string.weekly_comparison_same, thisWeekTotal)
        }
    }

    private fun buildChartSeries(summaries: List<NightlySummary>, days: Int): List<NightPoint> {
        val summaryByKey = summaries.associateBy { it.dayKey }
        val points = mutableListOf<NightPoint>()
        val calendar = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -(days - 1)) }
        repeat(days) {
            val key = dayKeyFormat.format(calendar.time)
            val summary = summaryByKey[key]
            points.add(NightPoint(calendar.timeInMillis, summary?.totalEvents ?: 0, summary?.possibleApneaCount ?: 0))
            calendar.add(Calendar.DAY_OF_YEAR, 1)
        }
        return points
    }

    // ---------------------------------------------------------------
    // Servicio de monitorización
    // ---------------------------------------------------------------

    private fun requestPermissionsAndStart() {
        val permissions = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        val allGranted = permissions.all {
            ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
        }
        if (allGranted) startDetectionService() else requestPermissionLauncher.launch(permissions.toTypedArray())
    }

    private fun startDetectionService() {
        val sensitivity = when (binding.sensitivityToggleGroup.checkedButtonId) {
            R.id.sensitivityLowButton -> SnoreDetector.Sensitivity.LOW
            R.id.sensitivityHighButton -> SnoreDetector.Sensitivity.HIGH
            else -> SnoreDetector.Sensitivity.MEDIUM
        }
        val intent = Intent(this, SnoreDetectionService::class.java).apply {
            putExtra(Constants.EXTRA_SENSITIVITY, sensitivity.name)
            putExtra(Constants.EXTRA_VIBRATE_ENABLED, binding.vibrateCheckBox.isChecked)
            putExtra(Constants.EXTRA_SOUND_ENABLED, binding.soundCheckBox.isChecked)
        }
        ContextCompat.startForegroundService(this, intent)
        serviceRunning = true
        updateStartStopButton()
    }

    private fun stopDetectionFlow() {
        startService(Intent(this, SnoreDetectionService::class.java).apply {
            action = Constants.ACTION_STOP
        })
        serviceRunning = false
        updateStartStopButton()
    }

    private fun updateStartStopButton() {
        binding.startStopButton.text = getString(
            if (serviceRunning) R.string.stop_monitoring else R.string.start_monitoring
        )
        binding.vibrateCheckBox.isEnabled = !serviceRunning
        binding.soundCheckBox.isEnabled = !serviceRunning
        for (i in 0 until binding.sensitivityToggleGroup.childCount) {
            binding.sensitivityToggleGroup.getChildAt(i).isEnabled = !serviceRunning
        }
    }

    private fun maybeRequestBatteryOptimizationExemption() {
        val powerManager = getSystemService(POWER_SERVICE) as PowerManager
        if (!powerManager.isIgnoringBatteryOptimizations(packageName)) {
            try {
                startActivity(
                    Intent(
                        Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                        Uri.parse("package:$packageName")
                    )
                )
            } catch (e: Exception) {
                // Algunas capas de fabricante (Xiaomi, Huawei...) bloquean este intent;
                // el usuario puede activarlo a mano desde Ajustes > Batería.
            }
        }
    }

    private fun playClip(event: SnoreEvent) {
        val path = event.clipFilePath ?: return
        playingClip?.release()
        playingClip = null
        try {
            playingClip = MediaPlayer().apply {
                setDataSource(path)
                setOnPreparedListener { it.start() }
                setOnCompletionListener { it.release(); playingClip = null }
                setOnErrorListener { mp, _, _ ->
                    mp.release()
                    playingClip = null
                    Toast.makeText(
                        this@MainActivity, getString(R.string.playback_error), Toast.LENGTH_SHORT
                    ).show()
                    true
                }
                prepareAsync()
            }
        } catch (e: Exception) {
            Toast.makeText(this, getString(R.string.playback_error), Toast.LENGTH_SHORT).show()
        }
    }

    override fun onDestroy() {
        playingClip?.release()
        super.onDestroy()
    }
}
