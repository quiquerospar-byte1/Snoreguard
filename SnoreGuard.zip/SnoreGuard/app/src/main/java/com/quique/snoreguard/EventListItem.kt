package com.quique.snoreguard

sealed class EventListItem {

    data class DayHeader(
        val dayLabel: String,
        val dayKey: String,
        val eventCount: Int
    ) : EventListItem()

    data class EventRow(val event: SnoreEvent) : EventListItem()
}
