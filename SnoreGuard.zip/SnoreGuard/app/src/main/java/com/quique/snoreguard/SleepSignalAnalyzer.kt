package com.quique.snoreguard

/**
 * Clasifica cada ronquido individual en busca de señales notables: ronquido
 * profundo, posible pausa respiratoria, o patrón irregular.
 *
 * Deliberadamente separado de SnoreDetector.kt: SnoreDetector solo decide
 * "es esto un ronquido y se repite con ritmo respiratorio" -- la lógica que
 * mantiene vivo el servicio de fondo, y que no toca este fichero para nada.
 * Esta clase es una capa añadida ENCIMA, puramente de clasificación, que
 * consume los bursts que SnoreDetector ya ha detectado. Para ajustar
 * sensibilidad o añadir una señal nueva, se toca esto y SignalRules.kt --
 * nunca hace falta tocar la captura de audio ni el servicio.
 *
 * IMPORTANTE -- ninguna señal que devuelve esta clase es un diagnóstico
 * médico. Son patrones acústicos heurísticos (amplitud, duración y ritmo de
 * un burst relativos a TUS propios ronquidos normales de esa noche, no a un
 * valor clínico universal). Si "posible pausa respiratoria" aparece con
 * frecuencia, lo correcto es comentarlo con un médico -- la app no
 * sustituye un estudio del sueño.
 */
class SleepSignalAnalyzer {

    private data class BurstRecord(val timestampMs: Long, val durationMs: Long, val peakAmplitude: Int)

    // Solo bursts "normales" (sin señal) alimentan esta ventana. Si dejáramos
    // entrar los ya marcados como señal, la línea base se iría desplazando
    // hacia arriba con cada evento anómalo y acabaría por dejar de detectarlos.
    private val normalBaselineWindow = ArrayDeque<BurstRecord>()
    private var lastBurstTimestampMs: Long? = null

    fun analyze(timestampMs: Long, durationMs: Long, peakAmplitude: Int): SleepSignalType? {
        val previousTimestamp = lastBurstTimestampMs
        lastBurstTimestampMs = timestampMs

        if (normalBaselineWindow.size < SignalRules.MIN_BASELINE_SAMPLES) {
            addToBaseline(timestampMs, durationMs, peakAmplitude)
            return null
        }

        val baselineAmplitude = median(normalBaselineWindow.map { it.peakAmplitude.toDouble() })
        val baselineDuration = median(normalBaselineWindow.map { it.durationMs.toDouble() })
        val baselineGap = median(computeBaselineGaps())

        val signal = when {
            previousTimestamp != null && isPossibleBreathingPause(
                gapMs = timestampMs - previousTimestamp,
                peakAmplitude = peakAmplitude,
                baselineGap = baselineGap,
                baselineAmplitude = baselineAmplitude
            ) -> SleepSignalType.POSSIBLE_BREATHING_PAUSE

            peakAmplitude > baselineAmplitude * SignalRules.DEEP_SNORE_AMPLITUDE_MULTIPLIER ->
                SleepSignalType.DEEP_SNORE

            durationMs > baselineDuration * SignalRules.IRREGULAR_BURST_DURATION_MULTIPLIER ->
                SleepSignalType.IRREGULAR_PATTERN

            else -> null
        }

        if (signal == null) {
            addToBaseline(timestampMs, durationMs, peakAmplitude)
        }

        return signal
    }

    private fun isPossibleBreathingPause(
        gapMs: Long,
        peakAmplitude: Int,
        baselineGap: Double,
        baselineAmplitude: Double
    ): Boolean {
        if (gapMs < SignalRules.APNEA_MIN_SILENCE_GAP_MS || gapMs > SignalRules.APNEA_MAX_SILENCE_GAP_MS) {
            return false
        }
        val gapIsAbnormal = gapMs > baselineGap * SignalRules.APNEA_GAP_VS_BASELINE_MULTIPLIER
        val recoveryIsLoud = peakAmplitude > baselineAmplitude * SignalRules.APNEA_RECOVERY_AMPLITUDE_MULTIPLIER
        return gapIsAbnormal && recoveryIsLoud
    }

    private fun addToBaseline(timestampMs: Long, durationMs: Long, peakAmplitude: Int) {
        normalBaselineWindow.addLast(BurstRecord(timestampMs, durationMs, peakAmplitude))
        while (normalBaselineWindow.size > SignalRules.BASELINE_WINDOW_SIZE) {
            normalBaselineWindow.removeFirst()
        }
    }

    private fun computeBaselineGaps(): List<Double> {
        val timestamps = normalBaselineWindow.map { it.timestampMs }
        if (timestamps.size < 2) return listOf(SignalRules.APNEA_MIN_SILENCE_GAP_MS.toDouble())
        return (1 until timestamps.size).map { (timestamps[it] - timestamps[it - 1]).toDouble() }
    }

    private fun median(values: List<Double>): Double {
        if (values.isEmpty()) return 0.0
        val sorted = values.sorted()
        val mid = sorted.size / 2
        return if (sorted.size % 2 == 0) (sorted[mid - 1] + sorted[mid]) / 2.0 else sorted[mid]
    }
}
