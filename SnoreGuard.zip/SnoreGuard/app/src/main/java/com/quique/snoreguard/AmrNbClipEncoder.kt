package com.quique.snoreguard

import android.media.MediaCodec
import android.media.MediaFormat
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Codifica PCM 16-bit/8kHz mono a AMR-NB, el códec de voz de banda estrecha
 * con menor tamaño soportado de forma nativa (y obligatoria) en Android.
 * A ~740 bytes/s, un clip de 5s ocupa ~3.6KB frente a los ~78KB que ocupaba
 * como WAV a la misma tasa (y ~156KB a los 16kHz originales).
 *
 * Escribe un fichero .amr "en crudo" (cabecera "#!AMR\n" + frames AMR), que
 * MediaPlayer reproduce de forma nativa sin necesidad de contenedor MP4/3GP.
 */
object AmrNbClipEncoder {

    private const val MIME_TYPE = MediaFormat.MIMETYPE_AUDIO_AMR_NB
    private const val BIT_RATE = 5900 // Modo MR59: pequeño y aún inteligible
    private const val TIMEOUT_US = 10_000L
    private val AMR_MAGIC = "#!AMR\n".toByteArray(Charsets.US_ASCII)

    fun encode(pcmSamples: ShortArray, sampleRate: Int, outputFile: File) {
        require(sampleRate == 8000) { "AMR-NB solo admite 8000Hz de entrada" }

        val format = MediaFormat.createAudioFormat(MIME_TYPE, sampleRate, 1).apply {
            setInteger(MediaFormat.KEY_BIT_RATE, BIT_RATE)
        }

        val codec = MediaCodec.createEncoderByType(MIME_TYPE)
        try {
            codec.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            codec.start()

            val pcmBytes = ByteBuffer.allocate(pcmSamples.size * 2)
                .order(ByteOrder.LITTLE_ENDIAN)
                .apply { pcmSamples.forEach { putShort(it) } }
                .array()

            FileOutputStream(outputFile).use { out ->
                out.write(AMR_MAGIC)
                runEncodeLoop(codec, pcmBytes, out)
            }
        } finally {
            codec.stop()
            codec.release()
        }
    }

    private fun runEncodeLoop(codec: MediaCodec, pcmBytes: ByteArray, out: FileOutputStream) {
        var inputOffset = 0
        var eosSent = false
        var outputDone = false
        val bufferInfo = MediaCodec.BufferInfo()

        while (!outputDone) {
            if (!eosSent) {
                val inputIndex = codec.dequeueInputBuffer(TIMEOUT_US)
                if (inputIndex >= 0) {
                    val inputBuffer = codec.getInputBuffer(inputIndex)
                    inputBuffer?.clear()
                    val remaining = pcmBytes.size - inputOffset
                    val capacity = inputBuffer?.remaining() ?: 0
                    val toCopy = minOf(remaining, capacity)

                    if (toCopy > 0) {
                        inputBuffer?.put(pcmBytes, inputOffset, toCopy)
                        inputOffset += toCopy
                        codec.queueInputBuffer(inputIndex, 0, toCopy, 0, 0)
                    } else {
                        codec.queueInputBuffer(
                            inputIndex, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM
                        )
                        eosSent = true
                    }
                }
            }

            val outputIndex = codec.dequeueOutputBuffer(bufferInfo, TIMEOUT_US)
            if (outputIndex >= 0) {
                val outputBuffer = codec.getOutputBuffer(outputIndex)
                if (outputBuffer != null && bufferInfo.size > 0) {
                    val chunk = ByteArray(bufferInfo.size)
                    outputBuffer.position(bufferInfo.offset)
                    outputBuffer.get(chunk)
                    out.write(chunk)
                }
                codec.releaseOutputBuffer(outputIndex, false)
                if (bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) {
                    outputDone = true
                }
            }
        }
    }
}
