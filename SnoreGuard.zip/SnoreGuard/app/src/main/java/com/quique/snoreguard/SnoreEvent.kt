package com.quique.snoreguard

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "snore_events")
data class SnoreEvent(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestampMs: Long,
    val estimatedDurationMs: Long,
    val peakAmplitude: Int,
    val clipFilePath: String?,
    val signalType: String? = null
)
