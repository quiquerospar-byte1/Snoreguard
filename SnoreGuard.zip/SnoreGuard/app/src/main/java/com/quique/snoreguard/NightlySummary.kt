package com.quique.snoreguard

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Un resumen por noche (solo recuentos, sin rutas de audio) para alimentar
 * los gráficos de tendencia. Deliberadamente separado de [SnoreEvent]: la
 * tabla de eventos detallados se poda a 30 días / 50 clips por el peso de
 * los audios, pero estas filas son minúsculas y se pueden retener meses sin
 * coste real de espacio.
 */
@Entity(tableName = "nightly_summaries")
data class NightlySummary(
    @PrimaryKey val dayKey: String,
    val totalEvents: Int = 0,
    val possibleApneaCount: Int = 0
)
