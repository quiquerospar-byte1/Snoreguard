package com.quique.snoreguard

import androidx.room.Dao
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface NightlySummaryDao {

    @Query("INSERT OR IGNORE INTO nightly_summaries (dayKey, totalEvents, possibleApneaCount) VALUES (:dayKey, 0, 0)")
    suspend fun ensureExists(dayKey: String)

    @Query("UPDATE nightly_summaries SET totalEvents = totalEvents + 1 WHERE dayKey = :dayKey")
    suspend fun incrementTotal(dayKey: String)

    @Query("UPDATE nightly_summaries SET possibleApneaCount = possibleApneaCount + 1 WHERE dayKey = :dayKey")
    suspend fun incrementApnea(dayKey: String)

    @Query("SELECT * FROM nightly_summaries WHERE dayKey >= :startKey ORDER BY dayKey ASC")
    fun observeSince(startKey: String): Flow<List<NightlySummary>>

    @Query("DELETE FROM nightly_summaries WHERE dayKey < :beforeKey")
    suspend fun deleteOlderThan(beforeKey: String)
}
