package com.quique.snoreguard

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.DrawableCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import java.text.SimpleDateFormat
import java.util.Locale

class EventsAdapter(
    private val onPlayClicked: (SnoreEvent) -> Unit,
    private val onDeleteDayClicked: (dayKey: String, dayLabel: String) -> Unit
) : ListAdapter<EventListItem, RecyclerView.ViewHolder>(DIFF_CALLBACK) {

    override fun getItemViewType(position: Int): Int = when (getItem(position)) {
        is EventListItem.DayHeader -> VIEW_TYPE_HEADER
        is EventListItem.EventRow -> VIEW_TYPE_EVENT
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        return if (viewType == VIEW_TYPE_HEADER) {
            DayHeaderViewHolder(
                inflater.inflate(R.layout.item_day_header, parent, false),
                onDeleteDayClicked
            )
        } else {
            EventViewHolder(
                inflater.inflate(R.layout.item_snore_event, parent, false),
                onPlayClicked
            )
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (val item = getItem(position)) {
            is EventListItem.DayHeader -> (holder as DayHeaderViewHolder).bind(item)
            is EventListItem.EventRow -> (holder as EventViewHolder).bind(item.event)
        }
    }

    class DayHeaderViewHolder(
        itemView: View,
        private val onDeleteDayClicked: (dayKey: String, dayLabel: String) -> Unit
    ) : RecyclerView.ViewHolder(itemView) {

        private val dayHeaderText: TextView = itemView.findViewById(R.id.dayHeaderText)
        private val deleteDayButton: View = itemView.findViewById(R.id.deleteDayButton)

        fun bind(header: EventListItem.DayHeader) {
            dayHeaderText.text = itemView.context.getString(
                R.string.day_header_format, header.dayLabel, header.eventCount
            )
            deleteDayButton.setOnClickListener {
                onDeleteDayClicked(header.dayKey, header.dayLabel)
            }
        }
    }

    class EventViewHolder(
        itemView: View,
        private val onPlayClicked: (SnoreEvent) -> Unit
    ) : RecyclerView.ViewHolder(itemView) {

        private val timeText: TextView = itemView.findViewById(R.id.eventTimeText)
        private val detailText: TextView = itemView.findViewById(R.id.eventDetailText)
        private val signalBadgeText: TextView = itemView.findViewById(R.id.signalBadgeText)
        private val signalAccentBar: View = itemView.findViewById(R.id.signalAccentBar)
        private val playButton: View = itemView.findViewById(R.id.playButton)
        private val timeFormat = SimpleDateFormat("HH:mm:ss", Locale.getDefault())

        fun bind(event: SnoreEvent) {
            timeText.text = timeFormat.format(event.timestampMs)
            detailText.text = itemView.context.getString(
                R.string.event_detail_format, event.estimatedDurationMs
            )
            bindSignalBadge(event.signalType)
            playButton.visibility = if (event.clipFilePath != null) View.VISIBLE else View.INVISIBLE
            playButton.setOnClickListener { onPlayClicked(event) }
        }

        private fun bindSignalBadge(signalType: String?) {
            val context = itemView.context
            val labelRes = when (signalType) {
                SleepSignalType.DEEP_SNORE.name -> R.string.signal_deep_snore
                SleepSignalType.POSSIBLE_BREATHING_PAUSE.name -> R.string.signal_possible_apnea
                SleepSignalType.IRREGULAR_PATTERN.name -> R.string.signal_irregular
                else -> null
            }
            val colorRes = when (signalType) {
                SleepSignalType.DEEP_SNORE.name -> R.color.signal_deep_snore
                SleepSignalType.POSSIBLE_BREATHING_PAUSE.name -> R.color.signal_possible_apnea
                SleepSignalType.IRREGULAR_PATTERN.name -> R.color.signal_irregular
                else -> R.color.primary
            }
            val accentColor = ContextCompat.getColor(context, colorRes)
            signalAccentBar.setBackgroundColor(accentColor)

            if (labelRes != null) {
                signalBadgeText.visibility = View.VISIBLE
                signalBadgeText.setText(labelRes)
                signalBadgeText.setTextColor(accentColor)
                signalBadgeText.background?.mutate()?.let { badgeBackground ->
                    DrawableCompat.setTint(badgeBackground, accentColor)
                    badgeBackground.alpha = 40
                }
            } else {
                signalBadgeText.visibility = View.GONE
            }
        }
    }

    companion object {
        private const val VIEW_TYPE_HEADER = 0
        private const val VIEW_TYPE_EVENT = 1

        private val DIFF_CALLBACK = object : DiffUtil.ItemCallback<EventListItem>() {
            override fun areItemsTheSame(oldItem: EventListItem, newItem: EventListItem): Boolean {
                return when {
                    oldItem is EventListItem.EventRow && newItem is EventListItem.EventRow ->
                        oldItem.event.id == newItem.event.id
                    oldItem is EventListItem.DayHeader && newItem is EventListItem.DayHeader ->
                        oldItem.dayKey == newItem.dayKey
                    else -> false
                }
            }

            override fun areContentsTheSame(oldItem: EventListItem, newItem: EventListItem) =
                oldItem == newItem
        }
    }
}
