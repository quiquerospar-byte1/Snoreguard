package com.quique.snoreguard

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.DrawableCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import java.text.SimpleDateFormat
import java.util.Locale

class EventsAdapter(
    private val onPlayClicked: (SnoreEvent) -> Unit
) : ListAdapter<SnoreEvent, EventsAdapter.EventViewHolder>(DIFF_CALLBACK) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): EventViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_snore_event, parent, false)
        return EventViewHolder(view, onPlayClicked)
    }

    override fun onBindViewHolder(holder: EventViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    class EventViewHolder(
        itemView: View,
        private val onPlayClicked: (SnoreEvent) -> Unit
    ) : RecyclerView.ViewHolder(itemView) {

        private val timeText: TextView = itemView.findViewById(R.id.eventTimeText)
        private val detailText: TextView = itemView.findViewById(R.id.eventDetailText)
        private val signalBadgeText: TextView = itemView.findViewById(R.id.signalBadgeText)
        private val signalAccentBar: View = itemView.findViewById(R.id.signalAccentBar)
        private val playButton: View = itemView.findViewById(R.id.playButton)
        private val timeFormat = SimpleDateFormat("HH:mm:ss", Locale.getDefault())

        fun bind(event: SnoreEvent) {
            timeText.text = timeFormat.format(event.timestampMs)
            detailText.text = itemView.context.getString(
                R.string.event_detail_format, event.estimatedDurationMs
            )
            bindSignalBadge(event.signalType)
            playButton.visibility = if (event.clipFilePath != null) View.VISIBLE else View.INVISIBLE
            playButton.setOnClickListener { onPlayClicked(event) }
        }

        private fun bindSignalBadge(signalType: String?) {
            val context = itemView.context
            val labelRes = when (signalType) {
                SleepSignalType.DEEP_SNORE.name -> R.string.signal_deep_snore
                SleepSignalType.POSSIBLE_BREATHING_PAUSE.name -> R.string.signal_possible_apnea
                SleepSignalType.IRREGULAR_PATTERN.name -> R.string.signal_irregular
                else -> null
            }
            val colorRes = when (signalType) {
                SleepSignalType.DEEP_SNORE.name -> R.color.signal_deep_snore
                SleepSignalType.POSSIBLE_BREATHING_PAUSE.name -> R.color.signal_possible_apnea
                SleepSignalType.IRREGULAR_PATTERN.name -> R.color.signal_irregular
                else -> R.color.primary
            }
            val accentColor = ContextCompat.getColor(context, colorRes)
            signalAccentBar.setBackgroundColor(accentColor)

            if (labelRes != null) {
                signalBadgeText.visibility = View.VISIBLE
                signalBadgeText.setText(labelRes)
                signalBadgeText.setTextColor(accentColor)
                signalBadgeText.background?.mutate()?.let { badgeBackground ->
                    DrawableCompat.setTint(badgeBackground, accentColor)
                    badgeBackground.alpha = 40
                }
            } else {
                signalBadgeText.visibility = View.GONE
            }
        }
    }

    companion object {
        private val DIFF_CALLBACK = object : DiffUtil.ItemCallback<SnoreEvent>() {
            override fun areItemsTheSame(oldItem: SnoreEvent, newItem: SnoreEvent) =
                oldItem.id == newItem.id

            override fun areContentsTheSame(oldItem: SnoreEvent, newItem: SnoreEvent) =
                oldItem == newItem
        }
    }
}
