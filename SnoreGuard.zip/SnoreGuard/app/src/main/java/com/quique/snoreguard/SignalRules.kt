package com.quique.snoreguard

/**
 * ---------------------------------------------------------------------
 * ÚNICO FICHERO QUE DEBERÍAS NECESITAR TOCAR PARA AJUSTAR SENSIBILIDAD
 * DE RONQUIDO PROFUNDO, POSIBLE PAUSA RESPIRATORIA U OTRAS SEÑALES.
 * ---------------------------------------------------------------------
 *
 * No contiene lógica, solo números. Cambiar estos valores no puede romper
 * la captura de audio, el servicio en segundo plano ni el guardado de datos
 * -- como mucho, cambia qué se marca como "profundo" o "posible pausa". La
 * clasificación en sí vive en SleepSignalAnalyzer.kt.
 *
 * IMPORTANTE: son umbrales heurísticos, no clínicos, calculados relativos a
 * TUS propios ronquidos de esa noche (no hay una "amplitud de apnea"
 * universal). "Posible pausa respiratoria" es un patrón acústico -silencio
 * largo seguido de un resoplido fuerte-, no un diagnóstico. Si aparece con
 * frecuencia, coméntalo con un médico; esta app no sustituye un estudio del
 * sueño (polisomnografía).
 */
object SignalRules {

    // --- Ronquido profundo ---
    // Un burst se marca "profundo" si su amplitud pico supera en este
    // múltiplo la amplitud pico habitual (mediana) de tus ronquidos normales
    // de esta noche.
    const val DEEP_SNORE_AMPLITUDE_MULTIPLIER = 1.8

    // --- Posible pausa respiratoria ---
    // Patrón buscado: ronquido regular -> silencio anormalmente largo ->
    // resoplido/ronquido fuerte al reanudarse (la "recuperación").
    const val APNEA_MIN_SILENCE_GAP_MS = 15_000L        // por debajo, es un hueco normal entre respiraciones
    const val APNEA_MAX_SILENCE_GAP_MS = 90_000L        // por encima, se descarta (silencio real / te despertaste)
    const val APNEA_GAP_VS_BASELINE_MULTIPLIER = 2.5    // el hueco debe ser esto de grande frente a lo habitual
    const val APNEA_RECOVERY_AMPLITUDE_MULTIPLIER = 1.5 // el resoplido de recuperación debe ser más fuerte de lo normal

    // --- Patrón irregular (catch-all para futuras señales) ---
    // Se marca cuando un burst individual dura mucho más de lo habitual:
    // puede indicar un ronquido sostenido o un patrón atípico a revisar.
    const val IRREGULAR_BURST_DURATION_MULTIPLIER = 2.0

    // Nº de bursts "normales" recientes usados para calcular qué es "lo
    // habitual para ti" esta noche (amplitud, duración, ritmo).
    const val BASELINE_WINDOW_SIZE = 20
    const val MIN_BASELINE_SAMPLES = 5

    // Cada cuánto como mínimo se registra en el histórico una señal del
    // MISMO tipo (independiente del cooldown de 10 min de los eventos
    // normales de Constants.kt). Evita miles de escrituras si, por ejemplo,
    // hay ronquido profundo continuo durante horas.
    const val SIGNAL_LOG_COOLDOWN_MS = 180_000L
}
