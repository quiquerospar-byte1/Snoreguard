package com.quique.snoreguard

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface SnoreEventDao {

    @Insert
    suspend fun insert(event: SnoreEvent): Long

    @Query("SELECT * FROM snore_events ORDER BY timestampMs DESC")
    fun observeAll(): Flow<List<SnoreEvent>>

    @Query("DELETE FROM snore_events WHERE timestampMs < :beforeMs")
    suspend fun deleteOlderThan(beforeMs: Long)

    @Query("SELECT clipFilePath FROM snore_events WHERE clipFilePath IS NOT NULL ORDER BY timestampMs ASC")
    suspend fun getAllClipPathsOldestFirst(): List<String>
}
