package com.quique.snoreguard

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [SnoreEvent::class], version = 1, exportSchema = false)
abstract class SnoreDatabase : RoomDatabase() {

    abstract fun snoreEventDao(): SnoreEventDao

    companion object {
        @Volatile private var instance: SnoreDatabase? = null

        fun getInstance(context: Context): SnoreDatabase {
            return instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    SnoreDatabase::class.java,
                    "snore_guard.db"
                ).build().also { instance = it }
            }
        }
    }
}
