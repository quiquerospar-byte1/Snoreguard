package com.quique.snoreguard

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [SnoreEvent::class, NightlySummary::class],
    version = 2,
    exportSchema = false
)
abstract class SnoreDatabase : RoomDatabase() {

    abstract fun snoreEventDao(): SnoreEventDao
    abstract fun nightlySummaryDao(): NightlySummaryDao

    companion object {
        @Volatile private var instance: SnoreDatabase? = null

        fun getInstance(context: Context): SnoreDatabase {
            return instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    SnoreDatabase::class.java,
                    "snore_guard.db"
                )
                    // Añade una tabla nueva (resúmenes nocturnos). Migración
                    // destructiva explícita: se pierde el histórico ya
                    // guardado en este cambio de versión, una sola vez.
                    .fallbackToDestructiveMigration()
                    .build().also { instance = it }
            }
        }
    }
}
