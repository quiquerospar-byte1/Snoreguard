# Minify desactivado en el build de release por defecto (ver app/build.gradle.kts).
# Si lo activas en el futuro, añade aquí las reglas -keep necesarias para Room.
