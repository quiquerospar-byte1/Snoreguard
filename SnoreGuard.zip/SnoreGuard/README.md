# SnoreGuard

App Android nativa (Kotlin) que detecta ronquidos con el micrófono, avisa con
vibración/sonido para que cambies de postura, y guarda un registro con clips
de audio para revisar por la mañana. Funciona con la pantalla apagada porque
usa un **foreground service** con permiso de micrófono en segundo plano —
esto es justo lo que una app web (PWA) no puede hacer en Android/iOS.

## Cómo compilarla

1. Instala **Android Studio** (gratis, https://developer.android.com/studio).
2. Abre esta carpeta (`SnoreGuard/`) con "Open" en Android Studio.
3. Deja que sincronice Gradle (te lo pedirá automáticamente la primera vez;
   descargará las dependencias — necesita conexión a internet la primera vez).
4. Conecta tu móvil Android por USB con la "depuración USB" activada
   (Ajustes > Opciones de desarrollador), o crea un emulador.
5. Pulsa "Run" (▶). Se instalará directamente en el móvil.

No hace falta cuenta de Google Play para esto: es una instalación directa
("sideload"), no vas a publicarla en la Play Store.

## La primera vez que la abras

- Te pedirá permiso de **micrófono** (obligatorio) y de **notificaciones**
  (Android 13+, para que veas la notificación persistente mientras corre).
- Te pedirá excluirte de la **optimización de batería**. Acéptalo: si no,
  el sistema puede matar el servicio a mitad de la noche. En móviles Xiaomi,
  Huawei, Oppo, etc. puede que además tengas que ir a los ajustes de batería
  específicos del fabricante y añadir la app a la lista de "sin restricciones".

## Cómo funciona la detección (y sus límites)

No usa un modelo de IA entrenado — eso requeriría datos de entrenamiento
reales que no tengo. Usa una heurística basada en:

1. **Energía del sonido (RMS)** por encima del ruido ambiente de la habitación
   (el ruido de fondo se recalibra solo de forma continua).
2. **Tasa de cruces por cero** como aproximación barata de "es un sonido
   grave" (los ronquidos son predominantemente graves).
3. **Ritmo**: solo confirma "ronquido" si el patrón se repite varias veces
   con un intervalo compatible con la respiración (1.5–12s entre eventos),
   para no disparar con una tos suelta, un golpe o el despertador de al lado.

Esto es un punto de partida razonable, **no algo calibrado con datos reales**.
Vas a tener falsos positivos y negativos las primeras noches. Los parámetros
que más vas a querer tocar están en `Constants.kt` y en las constantes
`LOW_FREQ_ZCR_CEILING` / `MIN_ABSOLUTE_RMS` de `SnoreDetector.kt`:

- Si salta demasiado con ruido normal → baja la sensibilidad en la app, o
  sube `LOW_FREQ_ZCR_CEILING` para exigir sonidos más graves.
- Si no detecta ronquidos reales → sube la sensibilidad en la app.

## Qué guarda y dónde

- Cada evento **registrado** se guarda en una base de datos local (Room/SQLite)
  con hora, duración estimada y, si se pudo, un clip de audio de los ~5
  segundos alrededor del evento, en formato **AMR-NB** (~3.6KB por clip en
  vez de los ~78KB que ocupaba como WAV — es el códec de voz con menor
  tamaño soportado de forma nativa en Android).
- Los clips se guardan en el almacenamiento privado de la app (no ocupan
  galería ni piden permisos de almacenamiento) y se limitan a los **50** más
  recientes para no llenar el disco.
- Los eventos de hace más de 30 días se borran solos.

## Aviso vs. registro: dos cooldowns independientes

Hay una diferencia importante entre "que te avise" y "que quede guardado":

- **Aviso** (vibración/sonido): cooldown de 90s. Te puede nudgear varias
  veces por hora si sigues roncando.
- **Registro** (guardar en BD + clip): cooldown de **10 minutos**. Si no
  existiera este límite, una noche de ronquido continuo podría generar un
  guardado en disco cada 3-8 segundos — miles de escrituras, batería y
  espacio desperdiciados, y una lista de eventos inservible. Con 10 min de
  cooldown, los 50 clips cubren de forma representativa una noche completa
  en vez de agotarse en las 2 primeras horas.

Si prefieres una muestra más densa (a costa de gastar los 50 huecos antes),
baja `EVENT_LOG_COOLDOWN_MS` en `Constants.kt`.

## Otras optimizaciones de batería/recursos aplicadas

- **8kHz en vez de 16kHz**: la mitad de CPU, RAM y tamaño de clip, sin
  perder capacidad de detección (el ronquido no tiene contenido relevante
  por encima de ~2kHz, muy por debajo del límite de Nyquist a 8kHz).
- **Prioridad de hilo `THREAD_PRIORITY_URGENT_AUDIO`** en vez de un
  `Thread.MAX_PRIORITY` genérico: es la forma en que Android programa hilos
  de audio en tiempo real de manera más eficiente.
- El hilo que lee el micrófono **nunca** toca disco, base de datos ni hace
  llamadas al sistema (vibración, notificación): todo eso se difiere a una
  corrutina en segundo plano. El hilo de audio solo decide, con dos
  comparaciones de números, si hace falta avisar o registrar — y en la
  inmensa mayoría de los ronquidos detectados (los que caen dentro de
  cualquiera de los dos cooldowns) no hace nada en absoluto.

## Señales detectadas: ronquido profundo, posible pausa respiratoria y más

Además del registro normal de ronquidos, la app clasifica cada ronquido
individual buscando patrones notables:

- **🔴 Ronquido profundo**: amplitud muy por encima de tu media habitual esa noche.
- **⚠️ Posible pausa respiratoria**: silencio anormalmente largo (15-90s)
  seguido de un resoplido/ronquido fuerte al reanudarse — el patrón acústico
  clásico que se usa como proxy de apnea en apps de consumo.
- **🟡 Patrón irregular**: un ronquido individual que dura mucho más de lo
  habitual.

**Esto no es un diagnóstico médico.** Son patrones acústicos heurísticos,
calculados relativos a tus propios ronquidos de esa noche, no valores
clínicos. Si "posible pausa respiratoria" aparece con frecuencia, coméntalo
con un médico — un estudio del sueño (polisomnografía) es la única forma
real de diagnosticar apnea. La app lo señala en la propia lista de eventos
con ese mismo aviso, para que nunca se pierda de vista.

### Dónde tocar para ajustar esto (y por qué está separado así)

- **`SignalRules.kt`** — el único fichero pensado para editar. Son solo
  números (multiplicadores, ventanas de tiempo), sin lógica. Tocarlo no
  puede romper la captura de audio ni el servicio.
- **`SleepSignalAnalyzer.kt`** — la lógica de clasificación en sí, separada
  de `SnoreDetector.kt` (que sigue haciendo solo lo de antes: decidir si
  algo es un ronquido). Si algún día quieres añadir una señal nueva, se hace
  aquí y en `SignalRules.kt`, sin tocar la captura de audio ni el servicio
  en segundo plano.
- Los tres tipos de señal comparten el mismo límite de 50 clips y la
  retención de 30 días que el resto de eventos (misma tabla, mismo
  almacenamiento) — no hay una infraestructura paralela que mantener.
- Cada tipo de señal tiene su propio cooldown de registro (3 min, en
  `SignalRules.SIGNAL_LOG_COOLDOWN_MS`, independiente del de 10 min de los
  eventos normales), para que un ronquido profundo continuo no le quite el
  hueco a una posible pausa respiratoria que llegue justo después.

### Nota técnica si ya la habías instalado antes

Este cambio añade una columna a la base de datos. Como la app parte de cero
(nadie la tiene instalada todavía con datos reales), no hace falta
migración. Si en el futuro cambias el esquema de nuevo después de tener la
app ya instalada con datos que te importe conservar, necesitarás añadir una
migración de Room — si no, al abrir la app te borraría el historial
guardado hasta entonces.

## Compilar sin ordenador (GitHub Actions)

El proyecto incluye `.github/workflows/build.yml`: en cuanto subas el código
a un repositorio de GitHub, compila solo el APK de depuración en los
servidores de GitHub y lo deja descargable en la pestaña "Actions" de ese
repositorio, en la sección "Artifacts" de la ejecución. No hace falta tocar
el fichero para nada, se dispara solo con cada subida.

## Diseño

Identidad visual propia, no el Material azul por defecto: paleta "cielo
nocturno" (fondo navy `#0F1226`, acento ámbar `#FFB86B`) — deliberadamente
oscura y fija (no sigue el claro/oscuro del sistema), porque es una app que
se usa de noche, en la mesilla, con la luz apagada. Tarjetas con
`MaterialCardView`, control segmentado para la sensibilidad en vez de un
desplegable, badges de color por tipo de señal, e icono de app propio
(media luna + estela de puntos). Todo con `com.google.android.material`,
sin dependencias nuevas.

## Aviso importante

Esto **no es un dispositivo médico** ni sirve para diagnosticar apnea del
sueño. Si sospechas que puedes tener apnea (pausas en la respiración,
cansancio diurno importante, etc.), esto no la detecta de forma fiable —
consulta con un médico.
